<?php
class Multi extends AppModel {
	
    var $name = 'Multi';
    //var $hasOne = 'Filed';
	// var $hasMany = 'Multi';
	
}
