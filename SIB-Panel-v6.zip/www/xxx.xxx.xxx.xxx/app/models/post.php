<?
class Post extends AppModel {
	
    var $name = 'Post';
    //var $hasOne = 'Filed';
	 var $hasMany = 'Filed';
	 
}
